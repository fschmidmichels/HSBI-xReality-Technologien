# Unity + KI in VS Code mit Continue – Anleitung

Mit diesem Paket nutzt du **GPT OSS 120B**, **Mistral Small 4** und **GPT-6 (Sol und Luna)** über **KI:connect.nrw** direkt in VS Code. Die Modelle laufen auf Servern in NRW. Sie kennen die Unity-Regeln unseres Kurses und können im **Agent-Modus** selbst mit dem Unity-Editor und deiner Quest arbeiten.

Einrichtung: ca. 20 Minuten.

---

## Was ist im ZIP?

```
unity-kiconnectnrw-starter/
├── ANLEITUNG.md              → diese Anleitung
├── einrichten.cmd            → Einrichtung per Doppelklick (Windows)
├── einrichten.ps1            → wird von einrichten.cmd gestartet
├── continue-config/
│   ├── config.yaml           → Modelle, Unity-Doku → kommt nach %USERPROFILE%\.continue\
│   └── .env.example          → Vorlage für deinen API-Key
├── projekt-vorlage/          → kommt in den Hauptordner deines Unity-Projekts
│   ├── .continue/rules/      → Unity-Regeln, die das Modell beachtet
│   ├── .continue/prompts/    → Slash-Befehle /fehler /review /erklaeren /planen /quest
│   ├── .continue/mcpServers/ → Verbindung zum Unity-Editor für den Agent-Modus
│   └── .vscode/              → empfohlene VS Code-Erweiterungen
├── optional/
│   └── meta-vr.yaml          → Meta-VR-MCP-Server (nur bei Bedarf, siehe unten)
└── verbindungstest/
    └── test_kiconnect.py     → prüft deinen Key
```

**Wichtig:** Entpacke das ZIP zuerst (Rechtsklick → *Alle extrahieren*). Aus dem ZIP heraus funktioniert das Skript nicht.

---

## Schritt 1: Programme installieren

| Programm | Wofür | Installation |
|---|---|---|
| **VS Code** | Editor | https://code.visualstudio.com |
| **Unity CLI** | Unity-Editor steuern (Agent-Modus) | PowerShell öffnen und eingeben:<br>`irm https://unity.com/install.ps1 \| iex`<br>macOS: `curl -fsSL https://unity.com/install.sh \| bash` |
| **Node.js (LTS)** | wird für die Meta VR CLI gebraucht | https://nodejs.org |
| **Meta VR CLI** | Quest steuern (Agent-Modus) | Nach Node.js in einem **neuen** Terminal:<br>`npm install -g metavr` |
| Python 3 *(optional)* | Verbindungstest | https://python.org |

Danach **ein neues Terminal öffnen** und prüfen:
```
unity --version
metavr --help
```
Kommt bei beiden eine Ausgabe, passt alles.

### VS Code-Erweiterungen
Installiere in VS Code (Erweiterungen, *Strg+Shift+X*):
- **Continue** (KI-Assistent), **Version 2.0 oder neuer** – ältere Versionen können GPT-6 im Agent-Modus nicht richtig ansprechen
- **Unity** von Microsoft
- **C# Dev Kit** von Microsoft

In Unity unter *Edit → Preferences → External Tools* als *External Script Editor* **Visual Studio Code** wählen und *Regenerate project files* klicken.

---

## Schritt 2: API-Key bei KI:connect erzeugen

1. https://chat.kiconnect.nrw öffnen und mit deinem Hochschul-Login anmelden.
2. Unten links auf deinen Namen klicken → **API-Key-Management** → Key erzeugen.
3. **Key sofort kopieren.** Er wird später nicht mehr angezeigt.

> Der Key ist persönlich. Nicht weitergeben, nicht in Git einchecken, nicht in Screenshots zeigen.

---

## Schritt 3: Einrichtung ausführen

### Windows: automatisch
1. Doppelklick auf **`einrichten.cmd`**.
   Falls Windows warnt („Der Computer wurde durch Windows geschützt“): *Weitere Informationen → Trotzdem ausführen*.
2. Das Skript
   - prüft, ob die Programme aus Schritt 1 da sind,
   - kopiert `config.yaml` nach `%USERPROFILE%\.continue\` (eine vorhandene Datei wird vorher gesichert),
   - fragt nach deinem **API-Key** und speichert ihn in `%USERPROFILE%\.continue\.env`,
   - fragt nach dem **Ordner deines Unity-Projekts** und kopiert die Projektvorlage hinein,
   - fügt bei Bedarf das Unity-Paket **`com.unity.pipeline`** hinzu (für die Verbindung zum Editor).

   Den Projektpfad kopierst du am einfachsten aus dem Unity Hub: neben dem Projekt auf *⋯ → Show in Explorer*, dann die Adresszeile kopieren.
3. **VS Code komplett schließen und neu starten.**

### macOS / von Hand
1. Ordner `~/.continue/` öffnen (Finder: *Cmd+Shift+G*, `~/.continue` eingeben). Falls er fehlt, Continue einmal in VS Code öffnen.
2. `continue-config/config.yaml` dorthin kopieren und die vorhandene Datei ersetzen.
3. `continue-config/.env.example` dorthin kopieren, in **`.env`** umbenennen und den Key eintragen:
   ```
   KICONNECT_API_KEY=dein-key
   ```
4. Den **Inhalt** von `projekt-vorlage/` (die Ordner `.continue` und `.vscode`) in den Hauptordner deines Unity-Projekts kopieren. Das ist der Ordner mit `Assets/` und `ProjectSettings/`.
   Ordner mit Punkt am Anfang sind versteckt: im Finder mit *Cmd+Shift+.* einblenden.
5. **Nur macOS:** In `.continue/mcpServers/unity.yaml` `unity.exe` durch `unity` ersetzen (und in `optional/meta-vr.yaml` `metavr.cmd` durch `metavr`, falls du sie nutzt).
6. Im Projektordner im Terminal ausführen:
   ```
   unity pipeline install --project-path .
   ```
7. VS Code neu starten.

---

## Schritt 4: Testen

1. **Zuerst Unity öffnen** und warten, bis das Projekt fertig geladen ist.
2. **Danach VS Code starten** und den Projektordner öffnen (*Datei → Ordner öffnen*), nicht nur eine einzelne Datei.
   > **Die Reihenfolge ist wichtig.** Continue fragt den Unity-Editor nur einmal beim Start nach seinen Werkzeugen. Ist Unity da noch nicht bereit, kennt der Agent den Editor nicht. Dann in den Continue-Einstellungen bei den MCP-Servern **unity** neu laden oder VS Code neu starten (*Strg+Shift+P → Developer: Reload Window*).
3. Continue öffnen (Symbol in der linken Seitenleiste, oder *Strg+L*).
4. Oben über dem Eingabefeld ein Modell wählen, z. B. **GPT OSS 120B · Reasoning hoch** (Standard), und fragen:
   *„Was ist der Unterschied zwischen Update und FixedUpdate?“*
5. Unter dem Eingabefeld den Modus auf **Agent** stellen und fragen:
   *„Welche GameObjects sind in der aktuell geöffneten Szene?“*
   Continue fragt nach, ob es ein Werkzeug benutzen darf → **zustimmen**. Kommt eine Liste aus deiner Szene, funktioniert die Verbindung zum Editor.
6. **Quest testen (optional):** Quest per USB anschließen (Entwicklermodus an), im Agent-Modus fragen:
   *„Ist meine Quest verbunden? Welche Apps von mir sind installiert?“*
   Der Agent benutzt dafür den Befehl `metavr` im Terminal.

Zusätzlich kannst du den Key im Terminal prüfen:
```
python verbindungstest/test_kiconnect.py
```

---

## Chat oder Agent?

| Modus | Was passiert | Wann nutzen |
|---|---|---|
| **Chat** | Das Modell antwortet nur. Es ändert nichts. | Fragen, Erklärungen, Fehler verstehen |
| **Agent** | Das Modell darf Werkzeuge benutzen: Dateien bearbeiten, Terminal-Befehle ausführen, den Unity-Editor steuern, Apps auf der Quest installieren und starten, Logs lesen. | Szenen einrichten, Build auf die Quest bringen, Logs auswerten, mehrere Dateien ändern |

### Wie der Agent an Unity und die Quest kommt

- **Unity-Editor:** über einen **MCP-Server** (*Model Context Protocol*). Er gibt dem Modell Werkzeuge wie „Szenen-Hierarchie lesen“, „GameObject anlegen“ oder „Konsole lesen“, die direkt im offenen Editor wirken. Klappt das nicht, weicht der Agent auf die **Unity CLI** im Terminal aus (`unity command …`).
- **Quest:** über die **`metavr`-Befehlszeile** im Terminal (Gerät finden, APK installieren, App starten, Logs lesen).

**Warum nicht alles über MCP?** Jedes MCP-Werkzeug wird mit seiner Beschreibung bei **jeder** Anfrage an das Modell geschickt. Der Unity-Server bietet rund 170 Werkzeuge (≈ 33.000 Tokens), der Meta-VR-Server 42 (≈ 22.000 Tokens). Das würde das Kontextfenster füllen und das Token-Kontingent auffressen. Deshalb sind beim Unity-Server nur die ~30 wichtigsten Werkzeuge freigeschaltet (≈ 4.500 Tokens), und der Meta-VR-Server ist standardmäßig aus.

**Meta-VR-MCP-Server bei Bedarf einschalten** (z. B. für Performance-Analysen oder die Suche in der Meta-Dokumentation): `optional/meta-vr.yaml` nach `<dein Projekt>/.continue/mcpServers/` kopieren und VS Code neu laden. Wenn du fertig bist, die Datei wieder löschen.

**Keine `AGENTS.md`, `AGENT.md` oder `CLAUDE.md` im Projektordner.** Manche Anleitungen im Internet empfehlen solche Dateien für KI-Agenten. Continue liest eine `AGENTS.md` im Projektordner automatisch und schickt sie bei **jeder** Anfrage mit, auch im Chat-Modus. Das kostet Tokens und widerspricht oft den Kursregeln in `.continue/rules/`. Das Modell bekommt dann zwei verschiedene Anweisungen und arbeitet schlechter. Alle Regeln für den Agenten stehen bereits in `.continue/rules/`. Eigene Ergänzungen gehören als neue Datei dort hinein.

**Im Agent-Modus gilt:**
- **Lies jede Anfrage, bevor du zustimmst.** Continue zeigt dir, welches Werkzeug mit welchen Werten benutzt werden soll. Stimme nur zu, wenn du verstehst, was passiert.
- **Committe vorher in Git.** Dann kannst du Änderungen des Agenten jederzeit zurücknehmen.
- **Der Unity-Editor muss offen sein – und zwar bevor du VS Code startest**, damit der Agent ihn steuern kann. Hat dein Projekt Compile-Fehler, startet Unity im *Safe Mode* und der Agent kommt nicht an den Editor heran. Behebe dann zuerst die Fehler.
- **Agent ist kein Ersatz fürs Verstehen.** Lass dir erklären, was der Agent getan hat, z. B. mit *„Erkläre mir, was du gerade geändert hast und warum.“*

---

## Welches Modell wofür?

| Modell | Wofür |
|---|---|
| **GPT OSS 120B · Reasoning hoch** | **Standard.** Fragen, Debugging, Erklärungen, Agent-Modus |
| **Mistral Small 4 · Reasoning hoch** | Zweite Meinung. Längere Projekte (größeres Kontextfenster) |
| **GPT-6 Sol / GPT-6 Luna** | Nur gezielt: wenn GPT OSS und Mistral bei einem schwierigen Problem nicht weiterkommen (siehe unten) |
| **… · schnell** | Kurze Fragen, Code umformatieren. Spart Kontingent. |

„Reasoning hoch“ denkt länger nach und verbraucht mehr von deinem Kontingent.

### Achtung: Token-Limit bei GPT-6

Die GPT-6-Modelle (Sol und Luna) sind die stärksten Modelle im Paket. KI:connect begrenzt aber, wie viele **Tokens** (Textbausteine, grob ¾ Wort) du mit ihnen verbrauchen darfst: **derzeit 1.000.000 Tokens** (Stand: November 2026). Das klingt viel, **ist aber schnell erreicht.** Danach antworten die GPT-6-Modelle mit einem Fehler (meist `429`), bis das Kontingent wieder freigegeben wird.

Eine Beispielrechnung: Ein Agent-Auftrag mit zwei angehängten Skripten, den Projektregeln und etwas Verlauf schickt pro Anfrage schnell **30.000 Tokens** an das Modell. Braucht der Agent für die Aufgabe 15 Werkzeugaufrufe, sind das schon **rund 450.000 Tokens**. Nach zwei bis drei solchen Aufträgen ist die Million weg.

Warum es so schnell geht:
- **Jede Nachricht schickt den ganzen bisherigen Chat mit.** Nach zehn Nachrichten zählt jede neue Frage alle zehn vorherigen noch einmal mit.
- **Angehängte Dateien** (`@Files`, `@Codebase`) und die Projektregeln zählen bei jeder Nachricht mit.
- **Reasoning** verbraucht zusätzliche Tokens für das „Nachdenken“, auch wenn du sie nicht siehst.
- **Der Agent-Modus** ist am teuersten: Bei jedem Werkzeugaufruf (Szene lesen, Datei öffnen, Logs holen …) geht der gesamte Verlauf erneut an das Modell. Eine einzige Agent-Aufgabe kann so viele einzelne Anfragen auslösen.

So kommst du mit dem Limit aus:
- Arbeite standardmäßig mit **GPT OSS 120B**. Wechsle nur für ein festgefahrenes Problem zu GPT-6 und danach wieder zurück.
- Starte für jedes neue Thema einen **neuen Chat**, statt einen langen Verlauf weiterzuführen.
- Hänge nur die Dateien oder Code-Stellen an, die wirklich nötig sind.
- Nimm für einfache Fragen die **schnell**-Varianten.
- Setze GPT-6 im **Agent-Modus** nur sparsam ein, z. B. nicht für `/quest`.

### Achtung: Datenstand der Modelle

Ein Sprachmodell weiß nur, was bis zu seinem **Datenstand** (Wissensstichtag) im Internet stand. Alles, was danach erschienen ist, kennt es nicht.

| Modell | Datenstand |
|---|---|
| **GPT OSS 120B** | **Juni 2024** |
| **Mistral Small 4** | **ca. November 2024** |
| GPT-6 Sol | April 2026 |
| GPT-6 Luna | Mai 2026 |

Unser Kurs nutzt **Unity 6.3**, **URP 17.3**, **Meta XR SDK 207**, **OpenXR 1.18** und die **Unity CLI**. Das meiste davon ist **nach** dem Datenstand von GPT OSS und Mistral erschienen. Unity 6 selbst kam im Oktober 2024 heraus: GPT OSS kennt es höchstens als Vorabversion, Mistral nur ganz am Anfang. Daraus entstehen typische Probleme:

- **Veraltete API-Namen.** In Unity 6 wurden Dinge umbenannt, z. B. `Rigidbody.velocity` → `linearVelocity` und `drag` → `linearDamping`. Ältere Modelle schlagen oft noch die alten Namen vor. Folge: Warnungen wie *„… is obsolete“* oder Compiler-Fehler.
- **Veraltete Arbeitsweisen.** In URP 17 (Unity 6) läuft das Rendering über den *Render Graph*. Ältere Beispiele für eigene Render-Passes funktionieren dort nicht mehr. Ähnliches gilt für Menüs und Einstellungen im Editor, die anders heißen oder an anderer Stelle liegen.
- **Meta XR SDK.** Das SDK ändert sich schnell: Komponenten, Prefabs und *Building Blocks* werden umbenannt, zusammengelegt oder ersetzt. Ein Modell mit Stand 2024 beschreibt oft einen Aufbau, den es in Version 207 so nicht mehr gibt.
- **Neue Werkzeuge sind unbekannt.** Die Unity CLI (`unity …`) und die Meta VR CLI (`metavr`) kennen GPT OSS und Mistral gar nicht. Im Agent-Modus muss es deren Befehle erst mit `--help` nachschlagen. Die Projektregeln weisen es darauf hin.
- **Das Modell merkt es nicht.** Ein Modell sagt nicht von selbst „das kenne ich nicht“. Es antwortet genauso überzeugt mit veraltetem oder erfundenem Wissen. Klingt eine Antwort plausibel, heißt das noch nicht, dass sie zu unserer Unity-Version passt.

**Was du dagegen tun kannst:**
- **`@Docs` benutzen.** Damit liest das Modell die aktuelle Unity-Dokumentation, statt sich auf sein altes Wissen zu verlassen. Beispiel: `@Docs Unity Scripting API` + *„Wie setze ich die Geschwindigkeit eines Rigidbody?“*
- **Fehler zurückgeben.** Meldet der Compiler *obsolete* oder *does not exist*, kopiere die vollständige Meldung in den Chat. Meist nennt Unity den neuen Namen gleich mit.
- **Bei XR-Fragen Code aus dem Projekt zeigen.** Mit `@Files` vorhandene Skripte oder Prefab-Namen anhängen, damit das Modell sieht, wie das SDK bei uns tatsächlich aussieht.
- **Im Zweifel ein neueres Modell fragen.** Bei Fragen zu sehr neuen Funktionen kennt GPT-6 mehr, aber Token-Limit beachten.
- **Selbst prüfen.** Im Inspector und in der offiziellen Dokumentation nachsehen, ob es die vorgeschlagene Komponente oder Einstellung wirklich gibt.

---

## So holst du das Beste heraus

**Kontext mitgeben.** Tippe `@` im Chat:
- `@Files`: bestimmte Skripte anhängen
- `@Problems`: aktuelle Compiler-Fehler aus VS Code
- `@Docs`: in der Unity-Dokumentation nachschlagen (erst *Unity Scripting API* wählen, dann fragen)
- `@Codebase`: im ganzen Projekt nach passendem Code suchen

**Code markieren.** Code markieren und *Strg+L* drücken: Er landet im Chat. Mit *Strg+I* bearbeitest du ihn direkt im Editor.

**Slash-Befehle.** Tippe `/` im Chat:
- `/fehler` + Fehlermeldung aus der Unity-Konsole: Erklärung, Ursache, Lösung
- `/review`: markiertes Skript auf Bugs und Performance-Fallen prüfen
- `/erklaeren`: markierten Code Schritt für Schritt erklären
- `/planen` + Beschreibung: Feature planen, bevor du Code schreibst
- `/quest` (nur Agent-Modus): Build auf die Quest bringen, starten und Logs auswerten – Schritt für Schritt mit Rückfragen

**Fehler vollständig kopieren.** Aus der Unity-Konsole immer die ganze Meldung mit Stacktrace kopieren. Die Zeilennummern sind entscheidend. Im Agent-Modus kann das Modell die Konsole auch selbst lesen.

**Sei skeptisch.** Modelle erfinden manchmal Unity-Methoden, die es nicht gibt. Wenn der Compiler meckert, gib den Fehler an das Modell zurück oder schlag mit `@Docs` nach.

---

## Fehlerbehebung

| Problem | Lösung |
|---|---|
| `401 Unauthorized` | Key falsch kopiert oder abgelaufen. Neuen Key erzeugen, `einrichten.cmd` erneut starten (oder `.env` bearbeiten). |
| `model not found` / `404` | Modellname in `config.yaml` muss **exakt** der Modell-ID in KI:connect entsprechen. |
| GPT-6: `temperature` / `Unsupported parameter` | Bei den GPT-6-Modellen keine `temperature` in `config.yaml` eintragen. |
| `429 Too Many Requests` | Kontingent oder Parallel-Limit erreicht – bei GPT-6 passiert das schnell (siehe *Token-Limit bei GPT-6*). Zurück zu GPT OSS 120B wechseln oder später erneut versuchen. |
| Agent bekommt widersprüchliche Anweisungen / unbekannte Regel `AGENTS.md` taucht unter „rules“ auf | `AGENTS.md` (bzw. `AGENT.md`, `CLAUDE.md`) aus dem Projektordner löschen. Eigene Regeln als Datei in `.continue/rules/` anlegen. |
| Regeln/Slash-Befehle fehlen | In VS Code den **Projektordner** geöffnet? Liegt `.continue/` direkt darin (neben `Assets/`)? |
| `@Problems` ist leer | Unity-Erweiterung installiert? In Unity *Regenerate project files* ausgeführt? |
| MCP-Server rot / startet nicht | VS Code nach der Installation neu gestartet? Im Terminal `unity --version` testen. Notfalls den vollständigen Pfad eintragen (`where unity` bzw. `where metavr.cmd` zeigt ihn). |
| Agent kennt den Unity-Editor nicht / sucht im Internet nach „MCP“ | Unity war beim Start von VS Code noch nicht bereit. Unity zuerst öffnen, dann VS Code neu laden (*Developer: Reload Window*). Modus **Agent** gewählt? |
| Agent sieht den Unity-Editor nicht | Unity geöffnet? Projekt ohne Compile-Fehler? `com.unity.pipeline` im *Package Manager* vorhanden? Im Terminal `unity status` ausführen. |
| Agent findet die Quest nicht | USB-Kabel, Entwicklermodus, USB-Debugging in der Brille bestätigt? Im Terminal `metavr device list` testen. |
| Modell benutzt keine Werkzeuge | Modus **Agent** gewählt? Ausdrücklich bitten: *„Nutze das Unity-Werkzeug, um …“*. Klappt es mit GPT OSS 120B nicht, für diese Aufgabe GPT-6 Sol versuchen (Token-Limit beachten). |
| Skript startet nicht | ZIP vorher entpackt? Rechtsklick auf `einrichten.ps1` → *Mit PowerShell ausführen*. |
