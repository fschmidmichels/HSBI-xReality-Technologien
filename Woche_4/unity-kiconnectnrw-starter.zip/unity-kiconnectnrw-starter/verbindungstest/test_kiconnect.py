#!/usr/bin/env python3
"""
Verbindungstest für KI:connect – prüft, ob der API-Key funktioniert und
ob der Reasoning-Modus bei beiden Modellen tatsächlich ankommt.

Benötigt nur Python 3.8+ (keine Zusatzpakete).

Aufruf:
    python test_kiconnect.py                 # liest den Key aus ~/.continue/.env
    python test_kiconnect.py DEIN-API-KEY    # oder Key direkt angeben
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

API_BASE = "https://chat.kiconnect.nrw/api/v1"
MODELS = ["GPT OSS 120B", "Mistral Small 4"]

FRAGE = (
    "Ein Unity-Skript ruft in Update() GetComponent<Rigidbody>().AddForce(...) auf. "
    "Nenne in zwei Sätzen die zwei Probleme daran."
)


def lade_key() -> str:
    if len(sys.argv) > 1:
        return sys.argv[1].strip()
    if os.environ.get("KICONNECT_API_KEY"):
        return os.environ["KICONNECT_API_KEY"].strip()
    env_datei = Path.home() / ".continue" / ".env"
    if env_datei.exists():
        for zeile in env_datei.read_text(encoding="utf-8").splitlines():
            if zeile.strip().startswith("KICONNECT_API_KEY="):
                return zeile.split("=", 1)[1].strip().strip('"').strip("'")
    sys.exit("Kein API-Key gefunden. Lege ~/.continue/.env an oder übergib den Key als Argument.")


def anfrage(key: str, model: str, effort: str) -> dict:
    body = {
        "model": model,
        "messages": [{"role": "user", "content": FRAGE}],
        "max_tokens": 4000,
        "reasoning_effort": effort,
    }
    req = urllib.request.Request(
        f"{API_BASE}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST",
    )
    start = time.time()
    with urllib.request.urlopen(req, timeout=180) as resp:
        daten = json.loads(resp.read().decode("utf-8"))
    daten["_sekunden"] = time.time() - start
    return daten


def reasoning_info(daten: dict) -> str:
    msg = (daten.get("choices") or [{}])[0].get("message", {}) or {}
    usage = daten.get("usage", {}) or {}
    details = usage.get("completion_tokens_details") or {}
    teile = []
    if details.get("reasoning_tokens") is not None:
        teile.append(f"Reasoning-Tokens: {details['reasoning_tokens']}")
    gedanke = msg.get("reasoning_content") or msg.get("reasoning")
    if gedanke:
        teile.append(f"Denktext: {len(gedanke)} Zeichen")
    teile.append(f"Ausgabe-Tokens gesamt: {usage.get('completion_tokens', '?')}")
    teile.append(f"Dauer: {daten['_sekunden']:.1f} s")
    return " | ".join(teile)


def main() -> None:
    key = lade_key()
    print(f"Teste {API_BASE} …\n")
    alles_ok = True
    for model in MODELS:
        print(f"=== {model} ===")
        ergebnisse = {}
        for effort in ("none" if "Mistral" in model else "low", "high"):
            try:
                daten = anfrage(key, model, effort)
                ergebnisse[effort] = daten
                print(f"  reasoning_effort={effort:<5} OK  → {reasoning_info(daten)}")
            except urllib.error.HTTPError as e:
                alles_ok = False
                text = e.read().decode("utf-8", errors="replace")[:300]
                print(f"  reasoning_effort={effort:<5} FEHLER {e.code}: {text}")
                if e.code == 401:
                    sys.exit("\nAPI-Key ungültig oder abgelaufen. Neuen Key in KI:connect erzeugen.")
            except Exception as e:  # noqa: BLE001
                alles_ok = False
                print(f"  reasoning_effort={effort:<5} FEHLER: {e}")

        if len(ergebnisse) == 2:
            werte = [ergebnisse[k].get("usage", {}).get("completion_tokens", 0) or 0 for k in ergebnisse]
            if werte[1] > werte[0] * 1.5:
                print("  ✓ Reasoning wirkt: bei 'high' deutlich mehr Ausgabe-Tokens.")
            else:
                print("  ? Kaum Unterschied zwischen den Stufen – evtl. reicht KI:connect den")
                print("    Parameter nicht durch. Bei GPT OSS hilft dann 'Reasoning: high' im System-Prompt.")
            antwort = ergebnisse["high"]["choices"][0]["message"].get("content", "")
            print(f"  Antwort (high): {antwort.strip()[:300]}")
        print()

    print("Fertig." if alles_ok else "Fertig – mit Fehlern (siehe oben).")


if __name__ == "__main__":
    main()
