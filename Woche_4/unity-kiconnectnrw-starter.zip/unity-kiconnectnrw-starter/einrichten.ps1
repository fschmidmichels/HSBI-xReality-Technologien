﻿# Unity + KI:connect – Einrichtung von Continue (Windows)
# Start per Doppelklick auf "einrichten.cmd".
# Das Skript ändert nur Dateien in %USERPROFILE%\.continue und im gewählten Unity-Projekt.

$ErrorActionPreference = 'Stop'
$paket = Split-Path -Parent $MyInvocation.MyCommand.Path
$continueDir = Join-Path $env:USERPROFILE '.continue'

function Titel($text) { Write-Host ""; Write-Host "=== $text ===" -ForegroundColor Cyan }
function Ok($text)    { Write-Host "  [OK]   $text" -ForegroundColor Green }
function Warn($text)  { Write-Host "  [!]    $text" -ForegroundColor Yellow }
function JaNein($frage) {
    $a = Read-Host "$frage (j/n)"
    return ($a -match '^[jJyY]')
}

# ------------------------------------------------------------------
Titel "1/4  Voraussetzungen pruefen"
$fehlt = $false
foreach ($p in @(
    @{ cmd = 'code';       name = 'VS Code';    hilfe = 'https://code.visualstudio.com installieren' },
    @{ cmd = 'unity';      name = 'Unity CLI';  hilfe = 'PowerShell: irm https://unity.com/install.ps1 | iex' },
    @{ cmd = 'node';       name = 'Node.js';    hilfe = 'https://nodejs.org (LTS) installieren' },
    @{ cmd = 'metavr.cmd'; name = 'Meta VR CLI'; hilfe = 'Terminal: npm install -g metavr' }
)) {
    if (Get-Command $p.cmd -ErrorAction SilentlyContinue) { Ok $p.name }
    else { Warn "$($p.name) fehlt  ->  $($p.hilfe)"; $fehlt = $true }
}
if ($fehlt) {
    Warn "Fehlende Programme kannst du auch spaeter installieren (siehe ANLEITUNG.md, Schritt 1)."
    Warn "Danach VS Code neu starten, damit es die Programme findet."
}

# ------------------------------------------------------------------
Titel "2/4  Continue-Konfiguration nach $continueDir"
New-Item -ItemType Directory -Force -Path $continueDir | Out-Null

$ziel = Join-Path $continueDir 'config.yaml'
if (Test-Path $ziel) {
    $backup = "$ziel.backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Copy-Item $ziel $backup
    Ok "Alte config.yaml gesichert als $(Split-Path -Leaf $backup)"
}
Copy-Item (Join-Path $paket 'continue-config\config.yaml') $ziel -Force
Ok "config.yaml kopiert"

$envDatei = Join-Path $continueDir '.env'
$keyVorhanden = (Test-Path $envDatei) -and ((Get-Content $envDatei -Raw) -match 'KICONNECT_API_KEY=(?!hier-deinen-key)\S+')
if ($keyVorhanden -and -not (JaNein "  Es ist schon ein KI:connect-Key eingetragen. Ersetzen?")) {
    Ok "Vorhandener Key bleibt"
} else {
    Write-Host "  KI:connect-Key: https://chat.kiconnect.nrw -> Name unten links -> API-Key-Management"
    $sicher = Read-Host "  Key einfuegen (Rechtsklick) und Enter druecken" -AsSecureString
    $key = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sicher)).Trim()
    if ([string]::IsNullOrWhiteSpace($key)) {
        Warn "Kein Key eingegeben. Trage ihn spaeter in $envDatei ein."
        Copy-Item (Join-Path $paket 'continue-config\.env.example') $envDatei -Force
    } else {
        $andere = @()
        if (Test-Path $envDatei) { $andere = Get-Content $envDatei | Where-Object { $_ -notmatch '^\s*KICONNECT_API_KEY=' } }
        $inhalt = @($andere) + "KICONNECT_API_KEY=$key"
        [IO.File]::WriteAllLines($envDatei, [string[]]$inhalt, (New-Object Text.UTF8Encoding($false)))
        Ok ".env mit Key gespeichert"
    }
}

# ------------------------------------------------------------------
Titel "3/4  Projektvorlage ins Unity-Projekt kopieren"
$projekt = $null
while (-not $projekt) {
    $eingabe = (Read-Host "  Pfad zum Unity-Projekt (Ordner mit Assets\ und ProjectSettings\), leer = ueberspringen").Trim('"', ' ')
    if ([string]::IsNullOrWhiteSpace($eingabe)) { break }
    if ((Test-Path (Join-Path $eingabe 'Assets')) -and (Test-Path (Join-Path $eingabe 'ProjectSettings'))) {
        $projekt = (Resolve-Path $eingabe).Path
    } else {
        Warn "Dort liegen kein Assets\ und ProjectSettings\. Bitte den Hauptordner des Projekts angeben."
    }
}

if ($projekt) {
    $vorlage = Join-Path $paket 'projekt-vorlage'
    Copy-Item (Join-Path $vorlage '.continue') $projekt -Recurse -Force
    Ok ".continue\ (Regeln, Slash-Befehle, MCP-Server) kopiert"

    $vscodeZiel = Join-Path $projekt '.vscode'
    New-Item -ItemType Directory -Force -Path $vscodeZiel | Out-Null
    $extZiel = Join-Path $vscodeZiel 'extensions.json'
    if (Test-Path $extZiel) {
        Warn ".vscode\extensions.json existiert schon und bleibt unveraendert."
    } else {
        Copy-Item (Join-Path $vorlage '.vscode\extensions.json') $extZiel
        Ok ".vscode\extensions.json kopiert"
    }

    # ----------------------------------------------------------------
    Titel "4/4  Unity-Paket com.unity.pipeline (fuer den Unity-MCP-Server)"
    $manifest = Join-Path $projekt 'Packages\manifest.json'
    if ((Test-Path $manifest) -and ((Get-Content $manifest -Raw) -match 'com\.unity\.pipeline')) {
        Ok "Paket ist schon im Projekt"
    } elseif (-not (Get-Command unity -ErrorAction SilentlyContinue)) {
        Warn "Unity CLI fehlt. Spaeter im Projektordner ausfuehren: unity pipeline install --project-path ."
    } elseif (JaNein "  Paket jetzt mit 'unity pipeline install' hinzufuegen?") {
        & unity pipeline install --project-path "$projekt"
        if ($LASTEXITCODE -eq 0) { Ok "Paket hinzugefuegt" } else { Warn "Installation fehlgeschlagen (Exit-Code $LASTEXITCODE)" }
    }
} else {
    Warn "Projektvorlage uebersprungen. Kopiere spaeter .continue\ und .vscode\ aus projekt-vorlage\ in dein Projekt."
}

Titel "Fertig"
Write-Host "  Naechste Schritte:"
Write-Host "  1. VS Code komplett schliessen und neu starten."
Write-Host "  2. In VS Code: Datei -> Ordner oeffnen -> dein Unity-Projekt."
Write-Host "  3. Optional: python verbindungstest\test_kiconnect.py"
Write-Host ""
Read-Host "Enter zum Schliessen"
