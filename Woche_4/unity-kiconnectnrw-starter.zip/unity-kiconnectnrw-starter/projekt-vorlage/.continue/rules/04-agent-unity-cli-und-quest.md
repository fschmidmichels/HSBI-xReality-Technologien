---
name: Agent-Modus – Unity-Editor und Quest
alwaysApply: true
description: Wie der Agent den Unity-Editor (MCP-Werkzeuge oder Unity CLI) und die Meta Quest (metavr CLI) steuert.
---

# Werkzeuge im Agent-Modus

Gilt nur, wenn dir Werkzeuge zur Verfügung stehen (Agent-Modus). Im Chat-Modus hast du keine Werkzeuge: Wenn der Nutzer etwas im Editor oder auf der Quest erledigt haben will, sag ihm, dass er unten im Continue-Fenster auf **Agent** umschalten soll.

## Unity-Editor
Der Unity-Editor ist über **MCP** (Model Context Protocol) angebunden: Das sind deine Werkzeuge mit Namen wie `scene_list_open`, `editor_search`, `gameobject_find`, `gameobject_create`, `component_get_properties`, `component_set_properties`, `console_get`, `editor_playmode_start`. Sie wirken direkt im geöffneten Editor.

1. **Bevorzugt die Unity-MCP-Werkzeuge** benutzen, und zwar **gezielt und klein**: Szenen enthalten mit dem XR-Rig tausende Objekte. Große Abfragen sprengen den Kontext.
   - Objekte der obersten Ebene: `editor_search` mit `query: "h: is:root"`.
   - Bestimmte Objekte: `gameobject_find` mit `name`, `type` (Komponente, z. B. `Rigidbody`) oder `tag`, oder `editor_search` mit `query: "h: <Name>"`.
   - Offene Szenen und Anzahl der Wurzelobjekte: `scene_list_open`.
   - Konsole: `console_get` mit `level: "error"` und kleinem `tail` (z. B. 20).
   - Einzelne Eigenschaften einer **bekannten** Komponente: `component_get_properties` mit `target` (Hierarchiepfad wie `/BowlingBall`) und `type`.
   - **Alle Komponenten** oder **Kinder** eines Objekts: Es gibt dafür kein eigenes Werkzeug. **Nicht raten** und nicht Typ für Typ durchprobieren, sondern **einmal** `script_eval` mit einem kurzen, nur lesenden C#-Ausdruck aufrufen, der mit `return` einen String liefert:
     - Komponenten: `return string.Join(", ", System.Linq.Enumerable.Select(UnityEngine.GameObject.Find("NAME").GetComponents<UnityEngine.Component>(), c => c.GetType().Name));`
     - Kinder: `var t = UnityEngine.GameObject.Find("NAME").transform; var n = new System.Collections.Generic.List<string>(); foreach (UnityEngine.Transform c in t) n.Add(c.name); return string.Join(", ", n);`
     - Regeln für `script_eval`: **keine** `using`-Zeilen (führen zu Fehler CS1001), Typen voll ausschreiben (`UnityEngine.…`, `System.…`), am Ende `return` mit einem String.
     - `GameObject.Find` findet nur aktive Objekte; bei `null` dem Nutzer das sagen.
   - `script_eval` **nur zum Lesen** verwenden. Nichts damit verändern, erzeugen oder löschen – dafür gibt es die `gameobject_*`-, `component_*`- und `prefab_*`-Werkzeuge.
   - **Nie** den kompletten Szenenbaum abrufen (`scene get_hierarchy` – auch nicht über die CLI).
   - `gameobject_find` **nie** nur mit sehr häufigen Typen (`Transform`, `GameObject`, `MeshRenderer`, `Collider`) aufrufen – das liefert tausende Objekte. Immer mit `name` kombinieren oder `editor_search` mit `limit` benutzen.
2. **Fehlen diese Werkzeuge** (du siehst z. B. nur ein Status-Werkzeug), war der Editor beim Start von VS Code noch nicht bereit. Sag das dem Nutzer kurz (Lösung: MCP-Server in Continue neu laden oder VS Code neu starten) und weiche auf die **Unity CLI im Terminal** aus:
   - `unity status --format json --no-banner` → ist ein Editor verbunden (state "ready")?
   - `unity command --format json --no-banner --no-pager` → listet alle Befehlsgruppen und Befehle des Editors.
   - `unity command <gruppe> <befehl> --format json --no-banner`, z. B. `unity command scene list_open --format json --no-banner`.
   - Befehlsnamen nie raten. Erst auflisten oder `--help` benutzen.
3. Werte das Ergebnis über `success` und `errors[0].code` im JSON aus.
4. `.unity`-, `.prefab`- und `.asset`-Dateien **nie** als Text bearbeiten. Änderungen an Szenen und Prefabs nur über Werkzeuge bzw. `unity command`.
5. Kommt keine Verbindung zustande: mit `unity status` prüfen, ob der Editor wegen Compile-Fehlern im **Safe Mode** ist. Dann zuerst die C#-Fehler beheben.

## Meta Quest (Terminal, `metavr`)
- Geräte: `metavr device list --json`
- APK installieren: `metavr app install <pfad.apk>` · starten: `metavr app launch <paketname>` · stoppen: `metavr app stop <paketname>`
- Logs: `metavr log -n 200 -t Unity` (Unity-Ausgaben der App)
- Unklar? `metavr <befehl> --help`. Keine Befehle oder Flags raten.

## Sicherheit
- Vor Builds, Installationen, Löschen und Paketänderungen kurz erklären, was du vorhast, und auf Bestätigung warten.
- Keine Tokens, Passwörter oder Lizenzschlüssel in Befehle schreiben.

## Ausgaben knapp halten
- Lange Ausgaben (Logs, Befehlslisten, Hierarchien) nicht vollständig wiederholen, sondern das Relevante zusammenfassen.
