---
name: XR auf der Meta Quest
globs: "**/*.cs"
description: XR-spezifische Regeln für Meta Quest mit OpenXR und Meta XR SDK – Rig, Eingabe, Interaktion, Physik, UI und Performance. Anwenden bei Fragen zu VR, Controllern, Händen, Greifen, Headset oder Quest-Builds.
---

## Rig und Kamera
- Die Kopfposition kommt aus dem Tracking. Die Kamera im Rig (`OVRCameraRig` bzw. Building Block) nie per Skript verschieben oder drehen. Für Fortbewegung oder Teleport das **Rig-Root** bewegen.
- 1 Unity-Einheit = 1 Meter. Objekte in realistischer Größe bauen, sonst wirken sie in VR falsch.

## Eingabe und Interaktion
- Halte dich an den Stil des Bestandscodes: Controller-Eingaben über `OVRInput` (z. B. `OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.RTouch)`).
- Für Greifen, Zeigen, Poke und UI-Interaktion zuerst die Komponenten des **Meta XR Interaction SDK** bzw. die **Building Blocks** vorschlagen, statt eigene Raycasts oder Greif-Logik zu schreiben.
- Kein `Input.GetKey`/`Input.GetAxis` (alter Input Manager).

## Physik
- Gegriffene oder geworfene Objekte: Rigidbody mit `Interpolate`, `Collision Detection` mindestens `Continuous Dynamic` für schnelle Objekte (Bälle).
- Ruckeln gegriffener Objekte: Der Physik-Takt (`Time.fixedDeltaTime`) sollte zur Bildrate des Headsets passen (z. B. 1/72 oder 1/90 s). Weise darauf hin, statt nur Code-Symptome zu behandeln.

## UI
- In VR nur **World Space**-Canvas verwenden, kein Screen Space Overlay. Text gut lesbar platzieren (ca. 1–2 m Abstand).

## Performance (Quest = mobiles Gerät)
- Ziel: stabile 72 Hz oder mehr. Frame-Drops verursachen Übelkeit.
- Wenige Echtzeit-Lichter und -Schatten, Lightmaps bevorzugen. Teure Post-Processing-Effekte vermeiden.
- Draw Calls gering halten (Static Batching, GPU Instancing, gemeinsame Materialien).
- Keine Allokationen pro Frame, kein `Find`/`GetComponent` in `Update`.

## Testen
- Im Editor über Quest Link oder den **Meta XR Simulator**; auf dem Gerät per Android-Build (APK).
- `Debug.Log` auf der Quest über Logcat lesen (im Agent-Modus: `metavr log -t Unity`).
