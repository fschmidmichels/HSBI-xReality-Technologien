---
name: Unity C#-Konventionen
globs: "**/*.cs"
description: Code-Stil und Performance-Regeln für Unity-Skripte
---

## Felder und Inspector
- Felder für den Inspector als `[SerializeField] private`, nicht `public`. `[Header]`, `[Tooltip]` und `[Range]` sinnvoll einsetzen.
- Benennung: `PascalCase` für Klassen, Methoden und Properties; `camelCase` für Felder (ohne `m_` oder `_`, außer das Projekt nutzt es schon).
- `[RequireComponent(typeof(...))]`, wenn das Skript eine andere Komponente zwingend braucht.

## Lebenszyklus
- `Awake()`: eigene Referenzen holen (`GetComponent`). `OnEnable()/OnDisable()`: Events abonnieren und wieder abmelden. `Start()`: Referenzen auf andere Objekte.
- Physik (Rigidbody-Kräfte, `MovePosition`) in `FixedUpdate()`, Kamera-Nachführung in `LateUpdate()`.
- In Unity 6 heißt es `rigidbody.linearVelocity` (nicht mehr `velocity`) und `linearDamping` (nicht mehr `drag`).
- Zeitabhängige Bewegung in `Update()` immer mit `Time.deltaTime` multiplizieren.

## Performance (keine Mikro-Optimierung, aber die typischen Fallen)
- Kein `GetComponent`, `Find`, `FindObjectOfType` oder `Camera.main` in `Update()`; einmal cachen.
- Keine `new`-Allokationen pro Frame in `Update()` (Listen, Strings, Lambdas). Strings für UI nur bei Änderung neu setzen.
- `CompareTag("Enemy")` statt `tag == "Enemy"`.
- Viele kurzlebige Objekte (Projektile, Effekte): Object Pooling mit `UnityEngine.Pool.ObjectPool<T>`.

## Input
- Quest-Controller und Hände: siehe Regel „XR auf der Meta Quest“ (`OVRInput` bzw. Meta XR Interaction SDK).
- Tastatur, Maus, Gamepad: neues Input System (`UnityEngine.InputSystem`), bevorzugt mit Input Actions Asset und `PlayerInput` oder generierter C#-Klasse.
- Kein `Input.GetKey`/`Input.GetAxis` (altes Input Manager-System), außer der Nutzer verlangt es ausdrücklich.

## Null-Prüfungen
- Unity-Objekte nicht mit `?.` oder `??` prüfen (Unity überlädt `==`). Stattdessen `if (target != null)` oder `TryGetComponent(out var x)`.

## Koroutinen und Async
- Für einfache zeitliche Abläufe Koroutinen. Für Async-Code in Unity 6 `Awaitable` statt `Task`, damit Code auf dem Main Thread bleibt.
