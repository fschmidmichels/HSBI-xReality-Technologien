---
name: planen
description: Ein Feature planen, bevor Code geschrieben wird
invokable: true
---

Ich möchte ein Feature in meinem Unity-Projekt umsetzen. Schreibe noch keinen Code. Erstelle stattdessen einen Plan:

1. **Verständnis:** Fasse in eigenen Worten zusammen, was das Feature tun soll. Stelle Rückfragen, wenn etwas unklar ist.
2. **Unity-Bausteine:** Welche Komponenten, Systeme und Assets braucht es (z. B. Rigidbody, Collider, Animator, Input Actions, ScriptableObject, UI Toolkit)?
3. **Skripte:** Welche Klassen mit welcher Verantwortung? Wie kommunizieren sie (direkte Referenz, Events, ScriptableObject)?
4. **Schritte:** Eine nummerierte Reihenfolge, in der ich es umsetzen und nach jedem Schritt im Play Mode testen kann.
5. **Stolperfallen:** Was geht bei so etwas typischerweise schief?

Das Feature:
