---
name: erklaeren
description: Unity-Code Schritt für Schritt erklären
invokable: true
---

Erkläre den ausgewählten Code so, dass ihn jemand im zweiten Semester versteht:

1. Was macht das Skript insgesamt, in zwei Sätzen?
2. Gehe die wichtigen Teile der Reihe nach durch. Erkläre dabei die verwendeten Unity-Konzepte (z. B. wann Unity `Awake`, `Start`, `Update` aufruft, was `[SerializeField]` bewirkt, wie Kollisionen ausgelöst werden).
3. Was muss im Editor eingerichtet sein, damit das Skript funktioniert?
4. Eine Verständnisfrage, mit der ich mich selbst prüfen kann.

Keinen neuen Code schreiben, außer zur Veranschaulichung eines kurzen Ausschnitts.
