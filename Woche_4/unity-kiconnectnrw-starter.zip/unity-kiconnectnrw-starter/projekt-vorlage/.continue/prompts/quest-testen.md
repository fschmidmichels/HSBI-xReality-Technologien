---
name: quest
description: (Agent-Modus) Build auf die Quest bringen, starten und Logs prüfen
invokable: true
---

Bringe den aktuellen Stand des Projekts auf meine Quest und prüfe, ob er läuft. Gehe Schritt für Schritt vor und warte vor jedem Schritt, der etwas verändert, auf meine Bestätigung:

1. **Prüfen:** Ist der Unity-Editor verbunden (`unity status`)? Gibt es Compile-Fehler? Ist eine Quest angeschlossen (`metavr device list --json`)? Wenn etwas fehlt, sag mir, was ich tun muss, und hör hier auf.
2. **Bauen:** Android-APK mit der Unity CLI bauen. Nenne mir vorher den genauen Befehl und das Ausgabeverzeichnis.
3. **Installieren und starten:** APK mit `metavr app install <apk>` installieren und mit `metavr app launch <paketname>` starten. Den Paketnamen findest du in den Player Settings (`unity command` oder ProjectSettings).
4. **Logs prüfen:** Die Unity-Logs der App kurz nach dem Start lesen (`metavr log -n 300 -t Unity`). Fasse Fehler und Exceptions zusammen und nenne für jede die wahrscheinliche Ursache im Projekt.

Erkläre am Ende in zwei Sätzen, was passiert ist. Zusätzliche Hinweise von mir:
