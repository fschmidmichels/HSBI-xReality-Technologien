---
name: review
description: Unity-Skript prüfen – Bugs, Performance, Stil
invokable: true
---

Prüfe den ausgewählten Unity-Code. Ordne die Befunde nach Wichtigkeit:

1. **Fehler:** Dinge, die nicht funktionieren oder abstürzen können (Null-Referenzen, falscher Lebenszyklus, Physik in `Update`, vergessenes Abmelden von Events …).
2. **Performance-Fallen:** `GetComponent`/`Find` in `Update`, Allokationen pro Frame, unnötige Physik-Abfragen.
3. **Unity-Konventionen und Lesbarkeit:** `[SerializeField] private`, Benennung, verständliche Struktur.

Für jeden Befund: Zeile oder Stelle, kurz was das Problem ist, und wie man es behebt. Schreibe die Datei nicht komplett neu. Wenn der Code gut ist, sag das auch – und nenne höchstens zwei echte Verbesserungen.
