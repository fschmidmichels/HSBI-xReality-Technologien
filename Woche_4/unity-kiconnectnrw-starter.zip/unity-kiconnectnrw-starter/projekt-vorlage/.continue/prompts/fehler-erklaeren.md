---
name: fehler
description: Fehler aus der Unity-Konsole erklären und beheben
invokable: true
---

Ich habe einen Fehler in Unity. Gehe so vor:

1. **Bedeutung:** Was sagt die Fehlermeldung in einfachen Worten? Welcher Fehlertyp ist es (Compiler-Fehler, NullReferenceException, MissingReferenceException, Physik-/Setup-Problem …)?
2. **Ursache:** Wo genau im Code oder im Editor-Setup liegt die Ursache? Nutze Zeilennummern aus dem Stacktrace. Wenn die Ursache im Inspector liegen kann (nicht zugewiesenes Feld, fehlende Komponente, falscher Layer), sag das ausdrücklich.
3. **Lösung:** Zeige die minimale Korrektur. Erkläre, warum sie funktioniert.
4. **Vorbeugen:** Ein Satz, wie man diesen Fehler künftig vermeidet.

Wenn dir Informationen fehlen (z. B. das betroffene Skript oder der vollständige Stacktrace), frag zuerst danach.

Fehlermeldung und Kontext:
