@echo off
rem Startet das Einrichtungsskript, ohne die PowerShell-Ausfuehrungsrichtlinie dauerhaft zu aendern.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0einrichten.ps1"
